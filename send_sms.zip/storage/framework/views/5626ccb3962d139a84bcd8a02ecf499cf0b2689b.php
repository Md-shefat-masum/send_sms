<?php echo $__env->make('layouts.admin.logo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<ul class="metismenu" id="menu">
    <li>
        <div class="side_bar_top">
            <img src="<?php echo e(asset(''.Auth::user()->photo)); ?>" alt="profile pic">
            <h6><?php echo e(Auth::user()->name); ?></h6>
        </div>
    </li>
    <li>
        <a href="/admin">
            <div class="parent-icon"><i class="fa fa-envelope-o"></i></div>
            <div class="menu-title">Send Sms</div>
        </a>
    </li>

    <?php if(Auth::user()->role_id == 1): ?>
        <li>
            <a class="has-arrow" href="#">
                <div class="parent-icon"><i class="zmdi zmdi-account-box-o"></i></div>
                <div class="menu-title">User Management</div>
            </a>
            <ul class="">
                <li>
                    <a href="<?php echo e(route('admin_user_index')); ?>"><i class="zmdi zmdi-account-box-o"></i> All Users</a>
                </li>
            </ul>
        </li>
    <?php endif; ?>


    <li class="menu-label">Extra</li>
    
    <li>
        <a href="<?php echo e(route('logout')); ?>"
            onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
            <div class="parent-icon"><i class="zmdi zmdi-power-off"></i></div>
            <div class="menu-title">Logout</div>
        </a>
    </li>
    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
        <?php echo csrf_field(); ?>
    </form>
</ul>
<?php /**PATH G:\xammp\htdocs\send_sms\resources\views/layouts/admin/nav_sidebar.blade.php ENDPATH**/ ?>