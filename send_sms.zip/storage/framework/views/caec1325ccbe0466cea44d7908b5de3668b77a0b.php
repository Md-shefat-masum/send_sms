<?php echo $__env->make('layouts.admin.logo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<ul class="metismenu" id="menu">
    <li>
        <a href="/admin">
            <div class="parent-icon"><i class="zmdi zmdi-view-dashboard"></i></div>
            <div class="menu-title">Dashboard</div>
        </a>
    </li>

    <li>
        <a class="has-arrow" href="javascript:void();">
            <div class="parent-icon"><i class="zmdi zmdi-reader"></i></div>
            <div class="menu-title">Dropdown</div>
        </a>
        <ul class="">
            <li>
                <a href="index.html"><i class="zmdi zmdi-dot-circle-alt"></i> eCommerce v1</a>
            </li>
            <li>
                <a href="javascript:void();"><i class="zmdi zmdi-dot-circle-alt"></i> eCommerce v2</a>
                <ul class="">
                    <li>
                        <a href="index.html"><i class="zmdi zmdi-dot-circle-alt"></i> eCommerce v1</a>
                    </li>
                    <li>
                        <a href="dashboard-eCommerce-v2.html"><i class="zmdi zmdi-dot-circle-alt"></i> eCommerce v2</a>
                    </li>
                </ul>
            </li>
        </ul>
    </li>

    <li class="menu-label">Extra</li>
    <li>
        <a href="/" target="_blank">
            <div class="parent-icon"><i class="zmdi zmdi-globe"></i></div>
            <div class="menu-title">Visit Site</div>
        </a>
    </li>
    <li>
        <a href="<?php echo e(route('logout')); ?>"
            onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
            <div class="parent-icon"><i class="zmdi zmdi-power-off"></i></div>
            <div class="menu-title">Logout</div>
        </a>
    </li>
    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
        <?php echo csrf_field(); ?>
    </form>
</ul>
<?php /**PATH G:\xammp\htdocs\default_dashboard\laravel7\resources\views/layouts/admin/sidebar.blade.php ENDPATH**/ ?>