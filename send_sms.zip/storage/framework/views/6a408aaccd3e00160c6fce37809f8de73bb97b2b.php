<input type="hidden"  name="id" value="<?php echo e($user->id); ?>" id="">
<div class="form-group">
    <label for="input-1">Name</label>
    <input type="text" name="name" class="form-control" value="<?php echo e($user->name); ?>">
</div>
<div class="form-group">
    <label for="input-1">Last Name</label>
    <input type="text" name="last_name" class="form-control" value="<?php echo e($user->last_name); ?>">
</div>
<div class="form-group">
    <label for="input-2">Email</label>
    <input type="email" name="email" class="form-control" value="<?php echo e($user->email); ?>">
</div>
<div class="form-group">
    <label for="input-2">Phone</label>
    <input type="text" name="phone" class="form-control" value="<?php echo e($user->phone); ?>">
</div>
<?php /**PATH G:\xammp\htdocs\default_dashboard\laravel7\resources\views/admin/user_management/user/edit.blade.php ENDPATH**/ ?>