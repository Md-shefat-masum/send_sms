<div class="brand-logo">
    <img src="/icon.png" class="logo-icon" alt="logo icon" />
    <h5 class="logo-text">Admin Panel</h5>
    <div class="close-btn"><i class="zmdi zmdi-close"></i></div>
</div>
<?php /**PATH G:\xammp\htdocs\default_dashboard\laravel7\resources\views/layouts/admin/logo.blade.php ENDPATH**/ ?>