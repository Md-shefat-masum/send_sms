<div class="card-body">
    <div class="table-responsive">
        <table class="table text-center">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">First Name</th>
                    <th scope="col">Last Name</th>
                    <th scope="col">Email</th>
                    <th scope="col">Phone</th>
                    <th scope="col">Photo</th>
                    <th scope="col">Role</th>
                    <th scope="col">Created at</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $i=1; ?>

                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($i++); ?></th>
                        <td><?php echo e($item->name); ?></td>
                        <td><?php echo e($item->last_name); ?></td>
                        <td><?php echo e($item->email); ?></td>
                        <td><?php echo e($item->phone); ?></td>
                        <td> <img src="/<?php echo e($item->photo); ?>" style="height: 40px;" alt=""></td>
                        <td><?php echo e($item->role_id); ?></td>
                        <td><?php echo e($item->created_at->format('d-M-Y h:i:s a')); ?></td>
                        <td>
                            <ul class="d-flex justify-content-center table_action_list">
                                <li><a href="<?php echo e(route('admin_user_profile',$item->slug)); ?>"><i class="fa fa-plus"></i></a></li>
                                <li>
                                    <a href="#" class="edit_btn"
                                        data-href="<?php echo e(route('admin_user_update')); ?>"
                                        data-edit_href="<?php echo e(route('admin_user_edit')); ?>?id=<?php echo e($item->id); ?>"
                                        data-toggle="modal" data-target="#formemodal">
                                        <i class="fa fa-edit"></i>
                                    </a>
                                </li>
                                <li><a href="#" data-href="<?php echo e(route('admin_user_delete', $item->id)); ?>"
                                        class="delete_btn" data-toggle="modal"
                                        data-target="#modal-animation-1"><i class="fa fa-trash"></i></a>
                                </li>
                            </ul>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<div class="card-footer">
    <?php echo e($users->links()); ?>

</div>
<?php /**PATH G:\xammp\htdocs\default_dashboard\laravel7\resources\views/admin/user_management/user/table_data.blade.php ENDPATH**/ ?>