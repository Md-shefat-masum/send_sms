<div class="form-group">
    <label for="input-1">Name</label>
    <input type="text" class="form-control" id="input-1" placeholder="Enter Your Name">
</div>
<div class="form-group">
    <label for="input-2">Email</label>
    <input type="text" class="form-control" id="input-2" placeholder="Enter Your Email Address">
</div>
<div class="form-group">
    <label for="input-3">Password</label>
    <input type="text" class="form-control" id="input-3" placeholder="Enter Password">
</div>
<div class="form-group">
    <div class="icheck-material-white">
        <input type="checkbox" id="user-checkbox1" checked="">
        <label for="user-checkbox1">Remember me</label>
    </div>
</div>
